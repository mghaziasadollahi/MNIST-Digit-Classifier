import io
import pickle
import numpy as np
import PIL.Image
import PIL.ImageOps
from fastapi import FastAPI, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware

# Load the trained model
with open('mnist_model.pkl', 'rb') as f:
    model = pickle.load(f)

app = FastAPI()

# Allow CORS (Cross-Origin Requests)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def preprocess_image(image_bytes):
    """Preprocess the image to match MNIST format"""
    # Open image and convert to grayscale
    img = PIL.Image.open(io.BytesIO(image_bytes)).convert('L')
    
    # Resize to 28x28
    img = img.resize((28, 28), PIL.Image.LANCZOS)
    
    # Invert colors (MNIST has white digits on black background)
    img = PIL.ImageOps.invert(img)
    
    # Convert to numpy array and normalize
    img_array = np.array(img, dtype=np.float32).reshape(1, 784)
    img_array = img_array / 255.0  # Normalize to [0, 1]
    
    return img_array

@app.post("/predict_image")
async def predict_image(file: UploadFile = File(...)):
    try:
        # Read the uploaded image
        content = await file.read()
        
        # Preprocess the image
        img_array = preprocess_image(content)
        
        # Make prediction
        prediction = model.predict(img_array)
        
        return {"prediction": int(prediction[0])}
    
    except Exception as e:
        return {"error": str(e)}

# Test endpoint to verify model is working
@app.get("/test_model")
async def test_model():
    try:
        # Create a test sample that should predict as '0'
        test_sample = np.zeros((1, 784))
        test_sample[0, 100:150] = 1.0  # Add a white line
        prediction = model.predict(test_sample)
        return {"test_prediction": int(prediction[0]), "status": "Model is working"}
    except Exception as e:
        return {"error": str(e), "status": "Model failed"}